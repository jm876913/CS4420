#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>

#define REALLY_BIG_BUFFER 2000

int main(int argc, char *argv[])
{
  DIR *dp;
  FILE* fp;
  int pid;
  int read;
  struct dirent *ep;

  dp = opendir ("/proc");
  if (dp != NULL)
    {
      while (ep = readdir (dp))
      {
        pid = strtol(ep->d_name, NULL, 10);
        if( ( ep->d_type == DT_DIR ) && ( pid > 0) )
        {
          char temp[255];
          char* line_buffer = NULL;
          size_t blength;
          // do something with the directory ed->d_name
          sprintf(temp, "/proc/%d/stat", pid);
          // open a stat file
          fp=fopen(temp, "r");
          if(!fp)
          {
            fprintf(stderr, "Error: can't open file %s\n", temp);
            exit(-1);
          }
          // now read the line from the stat file just for fun
          // note that getline allocates the buffer memory
          while( (read=getline(&line_buffer, &blength, fp)) != -1)              			          
          {
            printf("Line: %s\n", line_buffer);
            free(line_buffer); // need to free the memory
          }
        }
      }
      closedir(dp);
    }
  else
  {
    perror ("Couldn't open the directory");
    exit(-1);
  }	

  return 0;
}